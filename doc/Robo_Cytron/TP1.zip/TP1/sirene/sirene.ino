const int buzzerPin = 23;
const int canalBuzzer = 1; // On utilise le canal 1 (le canal 0 est pour la LED)

void setup() {
  // Configuration du canal pour le buzzer
  ledcAttachChannel(buzzerPin, 2000, 8, canalBuzzer);
}

void loop() {
  // Faire varier la fréquence (sirène)
  for (int freq = 500; freq < 2000; freq += 10) {
    ledcWriteTone(buzzerPin, freq);
    delay(10);
  }
  for (int freq = 2000; freq > 500; freq -= 10) {
    ledcWriteTone(buzzerPin, freq);
    delay(10);
  }
}
