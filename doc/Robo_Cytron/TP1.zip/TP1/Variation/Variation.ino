// Définition de la broche
const int ledPin = 12; 

// Paramètres pour le PWM
const int frequence = 5000;
const int canal = 0;
const int resolution = 12; // Résolution de 8 bits (0 à 255)

void setup() {
  // Configuration des fonctionnalités PWM de la broche
  ledcAttachChannel(ledPin, frequence, resolution, canal);
}

void loop() {
  // Augmenter la luminosité
  for (int intensite = 0; intensite <= 4095; intensite++) 
  {
    ledcWrite(ledPin, intensite);
    delay(5);
  }
   // Diminuer la luminosité
  for (int intensite = 4095; intensite >= 0; intensite--) 
  {
    ledcWrite(ledPin, intensite);
    delay(5);
  }
   delay(1000);
}
