// Liste des broches des LEDs bleues sur la Maker ESP32
const int leds[] = {16, 17, 21, 22, 25, 26, 32, 33, 36, 39};
const int nbLeds = 10;

// Paramètres PWM
const int frequence = 5000;
const int resolution = 8;

void setup() {
  // On attache chaque LED à son propre canal (0 à 7)
  for (int i = 0; i < nbLeds; i++) {
    ledcAttachChannel(leds[i], frequence, resolution, i);
  }
}

void loop() {
  // On fait défiler le point lumineux
  for (int i = 0; i < nbLeds; i++) {
    // Allumer la LED actuelle au maximum
    ledcWrite(leds[i], 255);
    delay(100); // Vitesse du chenillard
    
    // Éteindre la LED actuelle avant de passer à la suivante
    ledcWrite(leds[i], 0);
  }
}
