const int buzzerPin = 23; // Broche du buzzer sur Robo-ESP32

void setup() {
  pinMode(buzzerPin, OUTPUT);
}

void loop() {
  // Joue une note (La4 = 440 Hz) pendant 500ms
  tone(buzzerPin, 440); 
  delay(500);
  
  // Arrête le son pendant 500ms
  noTone(buzzerPin);
  delay(500);
  
  // Joue une note plus aiguë (880 Hz)
  tone(buzzerPin, 880);
  delay(500);
  noTone(buzzerPin);
  delay(2000);
}

