void setup() {
  // Avec le nouveau Core ESP32 (v3.0+), on définit juste les pins en sortie
  pinMode(12, OUTPUT);
  pinMode(13, OUTPUT);
  pinMode(14, OUTPUT);
}

void loop() {
  // On fait varier la luminosité de 0 à 255
  for (int i = 0; i <= 255; i++) {
    analogWrite(12, i);      // LED 12 s'allume
    analogWrite(13, 255 - i); // LED 13 s'éteint
    analogWrite(14, i / 2);   // LED 14 à moitié
    delay(5);
  }
  
  for (int i = 255; i >= 0; i--) {
    analogWrite(12, i);
    analogWrite(13, 255 - i);
    analogWrite(14, i / 2);
    delay(5);
  }
}