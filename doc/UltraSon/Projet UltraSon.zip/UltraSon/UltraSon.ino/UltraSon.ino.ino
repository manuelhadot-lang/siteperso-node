#include <Wire.h>
#include "rgb_lcd.h"
#include <SoftwareSerial.h>

SoftwareSerial mySerial(11, 10);  // RX, TX

rgb_lcd lcd;
unsigned char data[4] = {};
float distance;

void setup()
{
  mySerial.begin(9600);
  lcd.begin(16, 2);
  lcd.print("Bienvenue !");
}

void loop() 
{
  do 
  {
    for (int i = 0; i < 4; i++) 
    {
      data[i] = mySerial.read();
    }
  } while (mySerial.read() == 0xff);
  mySerial.flush();
  if (data[0] == 0xff) {
    int sum;
    sum = (data[0] + data[1] + data[2]) & 0x00FF;
    if (sum == data[3]) {
      distance = (data[1] << 8) + data[2];
      if (distance > 250) {
        lcd.print("distance=");
        lcd.print(distance / 10);
        lcd.println("cm");
      } else {
        // lcd.println("  limite basse  ");
      }
    } else lcd.println("erreur");
  }
  delay(150);
  lcd.setCursor(0, 0);
}
