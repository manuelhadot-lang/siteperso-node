#include <Wire.h>
#include "rgb_lcd.h"
#include <SoftwareSerial.h>

SoftwareSerial mySerial(11,10); // RX, TX

rgb_lcd lcd;
unsigned char data[4]={};
float distance;

void setup() {
    //port série
    mySerial.begin(9600);
    // set up the LCD's number of columns and rows:
    lcd.begin(16, 2);
    // Print a message to the LCD.
    lcd.print("Vive les STI2D!");
    lcd.setCursor(0, 1);
    lcd.print("ANNEE 2023/2024");
}

void loop()
{

}




