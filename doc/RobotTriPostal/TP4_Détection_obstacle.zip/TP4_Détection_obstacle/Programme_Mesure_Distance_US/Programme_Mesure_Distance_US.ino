// Acquisition de l'information obstacle distant
// Carte connectique _ relié à la carte US
 
int Module_US = 6;    // Module connecté à la PIN 6

 
void setup() {
  // init communication serielle :
  Serial.begin(9600);
}
 
void loop()
{
  // variables
long duree, distance_cm;
 
// Emission d'une impulsion 
  pinMode(Module_US, OUTPUT);    
  digitalWrite(Module_US, LOW);
  delayMicroseconds(2);
  digitalWrite(Module_US, HIGH);
  delayMicroseconds(5);
  digitalWrite(Module_US, LOW); 
// Fin emission
 
  // Ecoute de l'echo 
  pinMode(Module_US, INPUT);        // config en entrée pour l'echo
  duree = pulseIn(Module_US, HIGH);  // Mesure du temps
 
  // convertion du temps en distance
  distance_cm = microsecondsToCentimeters(duree);  

  Serial.print(distance_cm);    // transmission serie des données
  Serial.print("cm");
  Serial.println();
  delay(500);
  Serial.print(duree);    // transmission serie des données
  Serial.print("us");
  Serial.println();
  delay(500);
  
}
 
// Fonctions de conversion 

long microsecondsToCentimeters(long microseconds)
{
  return microseconds / 29 / 2; 
}

