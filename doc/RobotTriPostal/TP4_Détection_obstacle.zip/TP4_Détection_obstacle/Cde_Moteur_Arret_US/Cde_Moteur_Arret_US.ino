// Commande Moteur - evite obstacles distants
// Carte connectique _ relié à la carte US
 
 
#include <Wire.h>
#include <Adafruit_MotorShield.h>
//#include "utility/Adafruit_PWMServoDriver.h"

// instanciation  de l'objet Pilotage a l'adresse par defaut I2C
Adafruit_MotorShield AFMS = Adafruit_MotorShield(); 

// Pilotage de M1
Adafruit_DCMotor *myMotor1 = AFMS.getMotor(3);
// Pilotage de M2
Adafruit_DCMotor *myMotor2 = AFMS.getMotor(4);


const int Module_US_D = 3;    // Module connecté à la PIN 3
const int Vitesse = 90;    // vitesse  pour les moteurs
const int distance_limite = 50;


void setup() {
 // Initialisation Moteurs
   // Pilotage par défaut a 1.6KHz
  AFMS.begin();  // create with the default frequency 1.6KHz
   
  // Vitesse 150 sur 255
  myMotor1->setSpeed(150);
  myMotor2->setSpeed(150);
  
 // Moteurs a l'arret
  myMotor1->run(RELEASE);
  myMotor2->run(RELEASE);
  
  // init communication serielle :
  Serial.begin(9600);
}
 
void loop()
{
  // variables
long duree_D, duree_G, distance_cm_D = 50 ;

   Avance();
   
   while (distance_cm_D > distance_limite)
   {
     // Emission d'une impulsion sur le capteur droit
    pinMode(Module_US_D, OUTPUT);    
    digitalWrite(Module_US_D, LOW);
    delayMicroseconds(2);
    digitalWrite(Module_US_D, HIGH);
    delayMicroseconds(5);
    digitalWrite(Module_US_D, LOW);  // Fin emission
 
    // Ecoute de l'echo 
    pinMode(Module_US_D, INPUT);        // config en entrée pour l'echo
    duree_D = pulseIn(Module_US_D, HIGH);  // Mesure du temps

    // convertion du temps en distance
    distance_cm_D = microsecondsToCentimeters(duree_D);  

    delay(200);
    Serial.print(distance_cm_D);    // transmission serie des données
    Serial.print(" cm");    // transmission serie des données
    Serial.println();
   }
   
  Arret();

}

 void Avance(void){
   myMotor2->run(FORWARD);   // Avance Moteur droit
   myMotor1->run(FORWARD);   // Avance Moteur gauche
}  


void Arret(void){
  myMotor2->run(RELEASE);         // Arret moteur Droit
  myMotor1->run(RELEASE);         // Arret moteur Gauche
}  
 
// Fonctions de conversion 

long microsecondsToCentimeters(long microseconds)
{
  // vitesse du son 340 m/s = 29 microseconds par centimetre.
  // Aller retour de l'onde divion par 2 du temps 
  return microseconds / 29 / 2;
}
