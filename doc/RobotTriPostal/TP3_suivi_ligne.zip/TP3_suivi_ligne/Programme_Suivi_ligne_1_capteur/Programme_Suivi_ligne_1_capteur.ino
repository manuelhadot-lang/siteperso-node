/* 
Guidage du chassis a l'aide d'un seul capteur de ligne
*/

#include <Wire.h>
#include <Adafruit_MotorShield.h>
#include "utility/Adafruit_PWMServoDriver.h"

// instanciation  de l'objet Pilotage a l'adresse par defaut I2C
Adafruit_MotorShield AFMS = Adafruit_MotorShield(); 

// Pilotage de M1
Adafruit_DCMotor *myMotor1 = AFMS.getMotor(1);
// Pilotage de M2
Adafruit_DCMotor *myMotor2 = AFMS.getMotor(2);

// Declarations
int Capteur_central = 6;    // connecte a la pin 7

void setup() 
{

  // Initialisation Moteurs
   // Pilotage par défaut a 1.6KHz
  AFMS.begin();  // create with the default frequency 1.6KHz
   
  // Vitesse 150 sur 255
  myMotor1->setSpeed(30);
  myMotor2->setSpeed(30);
  
 // Moteurs a l'arret
  myMotor1->run(RELEASE);
  myMotor2->run(RELEASE);
  
  // Capteur cental
  pinMode(Capteur_central, INPUT); // initialise la pin du capteur en entree  

}

// Boucle sans fin
void loop()                     
{
  while(digitalRead(Capteur_central)==HIGH)
  {
    Avance();
  }
  Arret();                    
}
 
 void Avance(void)
{
   myMotor2->run(FORWARD);   // Avance Moteur droit
   myMotor1->run(FORWARD);   // Avance Moteur gauche
}  

void Arret(void)
{
  myMotor2->run(RELEASE);         // Arret moteur Droit
  myMotor1->run(RELEASE);         // Arret moteur Gauche
}  

