/* 
Guidage du chassis a l'aide d'un seul capteur de ligne
*/

#include <Wire.h>
#include <Adafruit_MotorShield.h>
#include "utility/Adafruit_PWMServoDriver.h"

// instanciation  de l'objet Pilotage a l'adresse par defaut I2C
Adafruit_MotorShield AFMS = Adafruit_MotorShield(); 

// Pilotage de M1
Adafruit_DCMotor *myMotor1 = AFMS.getMotor(1);
// Pilotage de M2
Adafruit_DCMotor *myMotor2 = AFMS.getMotor(2);

// Declarations
int Capteur_central = 7;    // connecte a la pin 7
int Capteur_droit = 8;    // connecte a la pin 13
int Capteur_gauche = 5;    // connecte a la pin 8
int Lec_capteurs;
const int Vitesse = 90;    // vitesse normale pour les moteurs
const int Tourne_vite = 100;    // vitesse rapide pour les moteurs
const int Tourne_lent = 30;    // vitesse lente pour les moteurs

void setup() 
{

  // Initialisation Moteurs
   // Pilotage par défaut a 1.6KHz
  AFMS.begin();  // create with the default frequency 1.6KHz
   
  // Vitesse 150 sur 255
  myMotor1->setSpeed(100);
  myMotor2->setSpeed(100);
  
 // Moteurs a l'arret
  myMotor1->run(RELEASE);
  myMotor2->run(RELEASE);
  
  // Capteur cental
  pinMode(Capteur_central, INPUT); // initialise la pin du capteur en entree  
  pinMode(Capteur_droit, INPUT); // initialise la pin du capteur en entree  
  pinMode(Capteur_gauche, INPUT); // initialise la pin du capteur en entree  
}

// Boucle sans fin
void loop()                     
{
   Lec_capteurs=Lecture_Capteurs();
  switch(Lec_capteurs)
    {
      case 1 : Avance(); break;
      case 2 : Droite_Lente(); break;      
      case 3 : Gauche_Lente(); break;
      case 4 : Droite_Rapide(); break;
      case 5 : Gauche_Rapide(); break;
      case 0 : Arret(); while(1); break;     
      default : Arret(); break;      
    } 
   delay(10);                
}
 
 int Lecture_Capteurs(void)
 {
   if (digitalRead(Capteur_central)==HIGH)
     {
       if (digitalRead(Capteur_droit)==LOW && digitalRead(Capteur_gauche)==LOW ) return 1;
       if (digitalRead(Capteur_droit)==HIGH && digitalRead(Capteur_gauche)==LOW ) return 2; 
       if (digitalRead(Capteur_droit)==LOW && digitalRead(Capteur_gauche)==HIGH ) return 3;
       if (digitalRead(Capteur_droit)==HIGH && digitalRead(Capteur_gauche)==HIGH ) return 0;
     }
    else
      {
       if (digitalRead(Capteur_droit)==LOW && digitalRead(Capteur_gauche)==LOW ) return 0;
       if (digitalRead(Capteur_droit)==HIGH && digitalRead(Capteur_gauche)==LOW ) return 4; 
       if (digitalRead(Capteur_droit)==LOW && digitalRead(Capteur_gauche)==HIGH ) return 5;
       if (digitalRead(Capteur_droit)==HIGH && digitalRead(Capteur_gauche)==HIGH ) return 0;
      }
 }
 
 void Avance(void)
{
  myMotor1->setSpeed(Vitesse);
  myMotor2->setSpeed(Vitesse);
  myMotor2->run(FORWARD);   // Avance Moteur droit
  myMotor1->run(FORWARD);   // Avance Moteur gauche
}  

void Arret(void)
{
  myMotor2->run(RELEASE);         // Arret moteur Droit
  myMotor1->run(RELEASE);         // Arret moteur Gauche
}  

void Droite_Lente(void)
{
  myMotor2->setSpeed(20);   // Ralentit la vitese moteur pour tourner (max à 255)
  myMotor1->setSpeed(Tourne_lent);   //Ralenti la vitesse du moteur  (max à 255)
}


void  Gauche_Lente(void)
{
  myMotor1->setSpeed(20);   // Ralentit la vitese moteur pour tourner (max à 255)
  myMotor2->setSpeed(Tourne_lent);   // Fixe la vitesse du moteur Droit à 123 (max à 255)
}

void Droite_Rapide(void)
{
  myMotor2->setSpeed(0);   // Arrete la vitesse du moteur pour tourner (max à 255)
  myMotor1->setSpeed(Tourne_vite);   // Vitesse du moteur plus rapide que l'autre pour tourner (max à 255)

}


void  Gauche_Rapide(void)
{
  myMotor1->setSpeed(0);   // Arrete la vitesse du moteur pour tourner (max à 255)
  myMotor2->setSpeed(Tourne_vite);   // // Vitesse du moteur plus rapide que l'autre pour tourner (max à 255)
}

