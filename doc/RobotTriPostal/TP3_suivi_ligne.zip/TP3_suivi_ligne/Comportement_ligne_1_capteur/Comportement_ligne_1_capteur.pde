// Acquisition de l'information état de la ligne
// Carte connectique _ relie à la carte ligne binaire

int Capteur_ligne = 2;    // connecte a la pin 13


// Initialisations
void setup()
{
  pinMode(Capteur_ligne, INPUT); // initialise la pin du capteur en entrée  
  Serial.begin(9600);  // Initialisation de la liaison serie
}

void loop()                     
{
  int Etat_ligne = digitalRead(Capteur_ligne);      // Acquisition de l'etat de la ligne
  if(Etat_ligne == LOW) Serial.println("Blanc");    // Si detection de blanc transmettre blanc par liaison serie 
  else Serial.println("Noir");                      // Sinon transmettre noir par liaison serie 
  delay(50);                    
}
