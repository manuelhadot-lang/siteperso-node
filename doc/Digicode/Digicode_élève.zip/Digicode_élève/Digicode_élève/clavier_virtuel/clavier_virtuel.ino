//Gestion d'un digicode
#include <Adafruit_GFX.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_ILI9341.h>
#include <Adafruit_STMPE610.h>



// This is calibration data for the raw touch data to the screen coordinates
#define TS_MINX 150
#define TS_MINY 130
#define TS_MAXX 3800
#define TS_MAXY 4000

//tactile
#define STMPE_CS 8
Adafruit_STMPE610 ts = Adafruit_STMPE610(STMPE_CS);
//TFT
#define TFT_CS 10
#define TFT_DC 9
Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC);

#define code 2500
boolean appui= true;
boolean test_touch = false;
int nbr_appui = 0;
//variables sortie audio
int Audio = 2;
//variables relais
int RelaisControl_4 = 4;
int RelaisControl_3 = 5;
int RelaisControl_2 = 6;
int RelaisControl_1 = 7;
int touche;
int code_touche,code_touche_deux, code_touche_trois, code_touche_quatre;
char num[12] = { 0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x41,0x30,0x42};
int numb[12] = { 0,80,160,0,80,160,0,80,160,0,80,160};
int numc[12] = { 0,0,0,80,80,80,160,160,160,240,240,240 };


void bouton_yellow(char lettre,int posx,int posy)
{
   tft.fillRect(numb[posx]+5,numc[posy]+5,70,70,ILI9341_YELLOW);  
   tft.setCursor(numb[posx] +30, numc[posy] +28);
   tft.setTextColor(ILI9341_BLACK);
   tft.setTextSize(4);
   tft.println(num[lettre]);
}

void bouton_blue(char lettre, int posx, int posy)
{
	tft.fillRect(numb[posx] + 5, numc[posy] + 5, 70, 70, ILI9341_BLUE);
	tft.setCursor(numb[posx] + 30, numc[posy] + 28);
	tft.setTextColor(ILI9341_BLACK);
	tft.setTextSize(4);
	tft.println(num[lettre]);
}

void  beep(int son)
{
	int duree_son=0;
	if (son == 0)
	{
		while (duree_son < 50)
		{
			digitalWrite(Audio, HIGH);// 
			delay(2); // wait 1000 milliseconds (1 second)
			digitalWrite(Audio, LOW);// 
			delay(2);
			duree_son++;
		}
	}
	else if (son == 1)
	{
		while (duree_son < 500)
		{
			digitalWrite(Audio, HIGH);// 
			delay(1); // wait 1000 milliseconds (1 second)
			digitalWrite(Audio, LOW);// 
			delay(1);
			duree_son++;
		}
	}
	else if (son == 2)
	{
		while (duree_son < 160)
		{
			digitalWrite(Audio, HIGH);// 
			delay(1); // wait 1000 milliseconds (1 second)
			digitalWrite(Audio, LOW);// 
			delay(10);
			duree_son++;
		}
	}
}

void clavier_virtuel()
{
	int indice;
	for (indice = 0; indice < 12; indice++)
	{
		bouton_yellow(indice, indice, indice);
	}
}

void relais(void)
{
	digitalWrite(RelaisControl_4, HIGH);// 
	delay(5000); // wait 1000 milliseconds (1 second)
	digitalWrite(RelaisControl_4, LOW);// 
	delay(1000);
}

void setup(void)
{
	pinMode(RelaisControl_4, OUTPUT);
	pinMode(Audio, OUTPUT);
	Serial.begin(9600);
	tft.begin();
	if (!ts.begin()) { 
		Serial.println("Unable to start touchscreen.");
	} 
	else { 
		Serial.println("Touchscreen started."); 
	}
	tft.fillScreen(ILI9341_BLACK);
	clavier_virtuel();
}

void loop()
{
  // See if there's any  touch data for us
  if (!ts.bufferEmpty())
  {  
    TS_Point p = ts.getPoint(); 
    int x = p.x/10;
    int y = p.y/10;
	//r�currence math�matique
	//x = 380 / x;
	//y = 400 / y;
	if (appui)
	{
		if ((x > 0) && (x < 126) && (y > 0) && (y < 100))
		{
				bouton_blue(0, 0, 0);
				delay(200);
				bouton_yellow(0, 0, 0);
				appui = false;
				touche = 1;
				test_touch = true;
				beep(0);
		}
		else if ((x > 126) && (x < 252) && (y > 0) && (y < 100))
		{
			bouton_blue(1, 1, 1);
			delay(200);
			bouton_yellow(1, 1, 1);
			appui = false;
			touche = 2;
			test_touch = true;
			beep(0);
		}
		else if ((x > 252) && (y > 0) && (y < 100))
		{
			bouton_blue(2, 2, 2);
			delay(200);
			bouton_yellow(2, 2, 2);
			appui = false;
			touche = 3;
			test_touch = true;
			beep(0);
		}
		else if ((x > 0) && (x < 126) && (y > 100) && (y < 200))
		{
			bouton_blue(3, 3, 3);
			delay(200);
			bouton_yellow(3, 3, 3);
			appui = false;
			touche = 4;
			test_touch = true;
			beep(0);
		}
		else if ((x > 126) && (x < 252) && (y > 100) && (y < 200))
		{
			bouton_blue(4, 4, 4);
			delay(200);
			bouton_yellow(4, 4, 4);
			appui = false;
			touche = 5;
			test_touch = true;
			beep(0);
		}
		else if ((x > 252) && (y > 100) && (y < 200))
		{
			bouton_blue(5, 5, 5);
			delay(200);
			bouton_yellow(5, 5, 5);
			appui = false;
			touche = 6;
			test_touch = true;
			beep(0);
		}
		else if ((x > 0) && (x < 126) && (y > 200) && (y < 300))
		{
			bouton_blue(6, 6, 6);
			delay(200);
			bouton_yellow(6, 6, 6);
			appui = false;
			touche = 7;
			test_touch = true;
			beep(0);
		}
		else if ((x > 126) && (x < 252) && (y > 200) && (y < 300))
		{
			bouton_blue(7, 7, 7);
			delay(200);
			bouton_yellow(7, 7, 7);
			appui = false;
			touche = 8;
			test_touch = true;
			beep(0);
		}
		else if ((x > 252) && (y > 200) && (y < 300))
		{
			bouton_blue(8, 8, 8);
			delay(200);
			bouton_yellow(8, 8, 8);
			appui = false;
			touche = 9;
			test_touch = true;
			beep(0);
		}
		else if ((x > 0) && (x < 126) && (y > 300) && (y < 400))
		{
			bouton_blue(9, 9, 9);
			delay(200);
			bouton_yellow(9, 9, 9);
			appui = false;
			touche = 10;
			test_touch = true;
			beep(0);
		}
		else if ((x > 126) && (x < 252) && (y > 300) && (y < 400))
		{
			bouton_blue(10, 10, 10);
			delay(200);
			bouton_yellow(10, 10, 10);
			appui = false;
			touche = 0;
			test_touch = true;
			beep(0);
		}
		else if ((x > 252) && (y > 300) && (y < 400))
		{
			bouton_blue(11, 11, 11);
			delay(200);
			bouton_yellow(11, 11, 11);
			appui = false;
			touche = 11;
			test_touch = true;
			beep(0);
		}
	
	}
  }
  else
  {
	//
  }
}



