//Gestion d'un ecran tactile
#include <Adafruit_GFX.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_ILI9341.h>
#include <Adafruit_STMPE610.h>

// This is calibration data for the raw touch data to the screen coordinates
#define TS_MINX 150
#define TS_MINY 130
#define TS_MAXX 3800
#define TS_MAXY 4000

//tactile
#define STMPE_CS 8
Adafruit_STMPE610 ts = Adafruit_STMPE610(STMPE_CS);
//TFT
#define TFT_CS 10
#define TFT_DC 9
Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC);

//variables du projet
boolean appui = true;

// la fonction setup est activ�e lors d'un reset ou lorsque la carte est aliment�e
void setup()
{
	//gestion de la liaison s�rie avec l'�cran
	Serial.begin(9600);
	tft.begin();
	if (!ts.begin()) {
		Serial.println("Unable to start touchscreen.");
	}
	else {
		Serial.println("Touchscreen started.");
	}
	tft.fillScreen(ILI9341_BLACK);
	carre();
}

void carre()
{
	//Zone
	//�
	//d�finir
}

// la fonction loop est une boucle permanente
void loop()
{
	// d�tection du tactile
	if (!ts.bufferEmpty())
	{
		TS_Point p = ts.getPoint();
		int x = p.x / 10;
		int y = p.y / 10;
		//test de chaque bouton
		if (appui)
		{

		}

	while (1);

}
