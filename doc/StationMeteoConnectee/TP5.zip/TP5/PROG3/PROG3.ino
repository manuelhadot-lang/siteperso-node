#include <Wire.h>
#include <WiFi.h>
#include <Adafruit_ST7735.h>
#include <WebServer.h>
#include <DHT.h>
#include <SPIFFS.h>
#include <Adafruit_BMP280.h>
#include <ArduinoJson.h>
#include "Adafruit_TSL2591.h"

// === Paramètres Wi-Fi ===
const char* ssid = "Livebox-4DDD";     //SSID du WIfi Saint Erembert
const char* password = "LxHX4ntNb9vFLSR74n";      //mot de passe

// === Capteur DHT ===
#define DHTPIN 2        // Broche connectée au capteur DHT GPIO2
#define DHTTYPE DHT22   // Ou DHT11 selon ton capteur
DHT dht(DHTPIN, DHTTYPE);

// === Serveur web ===
WebServer server(80);

//capteur de lumière
Adafruit_TSL2591 tsl = Adafruit_TSL2591(2591);

// Broches SPI personnalisées
#define TFT_CS   6   // Chip Select GPIO6
#define TFT_DC   7   // Data/Command GPIO7
//cablage du MOSI(SDA) en broche GPIO10 et du SCK(SCL) en broche GPIO8

//couleurs
#define ST77XX_BLACK 0x0000
#define ST77XX_WHITE 0xFFFF
#define ST77XX_RED 0xF800
#define ST77XX_GREEN 0x07E0
#define ST77XX_BLUE 0x001F
#define ST77XX_CYAN 0x07FF
#define ST77XX_MAGENTA 0xF81F
#define ST77XX_YELLOW 0xFFE0
#define ST77XX_ORANGE 0xFC00

// Objet TFT avec RST  plus stable
#define TFT_RST 9 //GPIO9
Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);

//I2C
#define SDA_PIN 4 // D4
#define SCL_PIN 5 // D5

// === Page HTML intégrée dans le code ===
//début de page
const char INDEX_HTML[] PROGMEM = R"rawliteral(
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Station Meteo 2025/2026</title>
    <meta http-equiv="refresh" content="1">
</head>
<body>
    <div id="item1">STATION METEO</div>
    <br/><br/><br/>
    <div id="item2">
        <div>Température:</div>
        <div class="value">%TEMP%<a>°C</a></div>
    </div>
    <br/><br/><br/>
    <div id="item2">
        <div>Humidité:</div>
        <div class="value">%HUM%<a>%</a></div>
    </div>   
    <br/><br/><br/>
    <div id="item2">
        <div>Pression atmosphérique:</div>
        <div class="value">%BAR%<a>hPa</a></div>
    </div> 
    <br/><br/><br/>
      <div id="item2">
        <div>Luminosité:</div>
        <div class="value">%LUM%<a>Lux</a></div>
    </div> 

    <style>
        body {
            background-color: rgb(235, 230, 222);
            background-image: url(cielb.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            filter: brightness(100%); /* 100% pour luminosité normale */
            margin: 0;
            padding: 0;
        }  
        #item1 {
            font-size: 100px;
            text-align: center;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            text-shadow: 10px 10px 20px grey;
        }   
        #item2 {
            display: flex;
            justify-content: center;
            column-gap: 150px;
            font-size: 50px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            text-shadow: 10px 10px 20px grey;
        }   
    </style>  
</body>
</html>
)rawliteral";
//fin de page

//fonction température
void tempera()
{
  // Texte simple
  tft.setTextColor(ST77XX_RED);
  tft.setTextSize(1);
  tft.setCursor(10, 5);
  tft.print(F("Temp\x82rature:"));
  float temp=dht.readTemperature();
  tft.fillRect(10, 20, 100, 25 ,ST77XX_GREEN);
  tft.setCursor(10, 20);
  tft.setTextColor(0x001F);
  tft.setTextSize(2);
  tft.print(temp);
  tft.print("\xF7");
  tft.print("C");
}

//fonction humidité
void humid()
{
  // Texte simple
  tft.setTextColor(ST77XX_RED);
  tft.setTextSize(1);
  tft.setCursor(10, 45);
  tft.print(F("Humidit\x82:"));
  float humi=dht.readHumidity();
  tft.fillRect(10, 60, 100, 25 ,ST77XX_GREEN);
  tft.setCursor(10, 60);
  tft.setTextColor(0x001F);
  tft.setTextSize(2);
  tft.print(humi);
  tft.print(" %");
}

//fonction luminosité
void lumi()
{
  // Texte simple
  tft.setTextColor(ST77XX_RED);
  tft.setTextSize(1);
  tft.setCursor(10, 125);
  tft.print(F("Luminosit\x82:"));
  //
  //
  //
  //
  tft.fillRect(10, 140, 100, 25 ,ST77XX_GREEN);
  tft.setCursor(10, 140);
  tft.setTextColor(0x001F);
  tft.setTextSize(2);
  tft.print(lux);
  tft.setTextSize(1);
  tft.print(" Lux");
}

// === Fonction pour afficher la page avec les valeurs réelles ===
void handleRoot() 
{
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  //
  //
  //
  //
  String page = INDEX_HTML;
  page.replace("%TEMP%", String(temperature, 1));
  page.replace("%HUM%", String(humidity, 1));
  page.replace("%LUM%", String(luminosite, 1));
  server.send(200, "text/html", page.c_str());
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  // Initialisation du bus I2C sur les broches choisies
  Wire.begin(SDA_PIN, SCL_PIN);
 
  tft.initR(INITR_BLACKTAB); // Essaie aussi GREENTAB ou REDTAB si l'écran reste noir
  tft.setRotation(0);
  tft.fillScreen(ST77XX_GREEN);

  // Monter SPIFFS
  if (!SPIFFS.begin(true)) {
    Serial.println("Erreur SPIFFS !");
    return;
  }
  Serial.println("SPIFFS monté !");

  //Connexion Wi-Fi
  Serial.println("Connexion au Wi-Fi...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) 
  {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n Connecté !");
  Serial.print(" Adresse IP : ");
  Serial.println(WiFi.localIP());

  //  Routes serveur
  server.on("/", handleRoot);
  server.begin();
  Serial.println(" Serveur web démarré !");
}

void loop() {
  tempera();
  humid();
  lumi();
  delay(500);
  server.handleClient();
}