#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_TSL2591.h>

// Définition des broches I2C pour le XIAO ESP32-C3
#define I2C_SDA 4
#define I2C_SCL 5

Adafruit_TSL2591 tsl = Adafruit_TSL2591(2591); // ID du capteur

void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);
  // Configuration du capteur
  tsl.setGain(TSL2591_GAIN_MED); 
}

void loop() {
  uint32_t lum = tsl.getFullLuminosity();
  uint16_t full = lum & 0xFFFF;    // Canal 0 (Visible + IR)
  uint16_t ir = lum >> 16;         // Canal 1 (IR)
   // Calcul de l'éclairement en Lux
  float lux = tsl.calculateLux(full, ir);
  Serial.print("Lux: ");  Serial.println(lux);
  delay(500);
}
