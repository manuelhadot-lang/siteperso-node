#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>
#include <DHT.h>

// Broches SPI personnalisées
#define TFT_CS   6   // Chip Select   Sélection du circuit   norme SPI
#define TFT_DC   7   // Data/Command
//cablage du MOSI(SDA) en broche GPIO10 et du SCK(SCL) en broche GPIO8

//couleurs
#define ST77XX_BLACK 0x0000
#define ST77XX_WHITE 0xFFFF
#define ST77XX_RED 0xF800
#define ST77XX_GREEN 0x07E0
#define ST77XX_BLUE 0x001F
#define ST77XX_CYAN 0x07FF
#define ST77XX_MAGENTA 0xF81F
#define ST77XX_YELLOW 0xFFE0
#define ST77XX_ORANGE 0xFC00

// Objet TFT avec reset plus stable
#define TFT_RST 5
Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);

void setup() 
{
  // Initialisation de l'écran
  tft.initR(INITR_BLACKTAB); 
  tft.setRotation(0);
  tft.fillScreen(ST77XX_GREEN);
}

void loop() 
{
  tft.setTextColor(ST77XX_RED);
  tft.setTextSize(2);
  tft.setCursor(25, 50);
  tft.print("Station");
  tft.setCursor(35, 75);
  tft.print("Météo");
}


