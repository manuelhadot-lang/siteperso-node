//déclaration des librairies externes
   #include <Wire.h>
   #include <DHT.h>


   //Instanciation du capteur DHT en broche 3
   DHT dht(10, DHT22);


   //Fonction setup qui ne s'exécute qu’une seule fois
   void setup()
{
  Serial.begin();
  dht.begin();
}


//Fonction loop qui s’exécute en boucle
void loop()
{
  float temp=dht.readTemperature();
  Serial.print("température: ");
  Serial.print(temp);
  Serial.println(" °C");
  delay(1000);
  float humi=dht.readHumidity();
  Serial.print("humidité: ");
  Serial.print(humi);
  Serial.println(" %");
  delay(1000);
}
